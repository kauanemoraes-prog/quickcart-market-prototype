/**
 * Duplicate Equipment Modal
 * Opens when Duplicate is clicked in the equipment actions bar.
 * Shows one editable name field per selected equipment, prefilled with `{name}-copy`.
 * On confirm, invokes the caller-supplied callback with `[{ row, newName }]`.
 * Empty / whitespace-only field values fall back to `{originalName}-copy`.
 */

(function() {
  'use strict';

  var modal, fieldsHost, cancelBtn, closeBtn, confirmBtn;
  var currentRows = [];
  var currentCallback = null;

  function readOriginalName(row) {
    var input = row.querySelector('.equip-input--name');
    return input ? input.value.trim() : '';
  }

  function open(rows, onConfirm) {
    if (!rows || rows.length === 0) return;
    currentRows = rows;
    currentCallback = typeof onConfirm === 'function' ? onConfirm : null;

    var items = rows.map(function(row, idx) {
      return { idx: idx, name: readOriginalName(row) };
    });

    var tplEl = document.getElementById('duplicate-equipment-field-template');
    var tpl = Handlebars.compile(tplEl.innerHTML);
    fieldsHost.innerHTML = tpl({ items: items });

    modal.classList.add('modal-overlay--open');
    modal.setAttribute('aria-hidden', 'false');
    var firstInput = fieldsHost.querySelector('input');
    if (firstInput) firstInput.focus();
  }

  function close() {
    modal.classList.remove('modal-overlay--open');
    modal.setAttribute('aria-hidden', 'true');
    fieldsHost.innerHTML = '';
    currentRows = [];
    currentCallback = null;
  }

  function confirm() {
    if (!currentCallback) { close(); return; }
    var fields = fieldsHost.querySelectorAll('.dup-eq-modal__field');
    var results = [];
    fields.forEach(function(field, idx) {
      var input = field.querySelector('input');
      var original = field.getAttribute('data-original') || '';
      var entered = input.value.trim();
      var newName = entered.length > 0 ? entered : original + '-copy';
      results.push({ row: currentRows[idx], newName: newName });
    });
    var cb = currentCallback;
    close();
    cb(results);
  }

  window.DuplicateEquipmentModal = {
    init: function() {
      if (window.ModalShell) {
        window.ModalShell.render({
          modalId: 'duplicate-equipment-modal',
          sizeClass: 'modal--medium',
          title: 'Duplicate equipment',
          titleId: 'duplicate-equipment-modal-title',
          closeId: 'duplicate-equipment-modal-close',
          bodyHtml: window.ModalShell.bodyFrom('duplicate-equipment-modal-body'),
          footerHtml: window.ModalShell.bodyFrom('duplicate-equipment-modal-footer')
        });
      }
      modal = document.getElementById('duplicate-equipment-modal');
      if (!modal) return;
      fieldsHost = document.getElementById('duplicate-equipment-fields-host');
      cancelBtn = document.getElementById('duplicate-equipment-modal-cancel');
      confirmBtn = document.getElementById('duplicate-equipment-modal-confirm');
      closeBtn = document.getElementById('duplicate-equipment-modal-close');

      if (cancelBtn) cancelBtn.addEventListener('click', close);
      if (closeBtn) closeBtn.addEventListener('click', close);
      if (confirmBtn) confirmBtn.addEventListener('click', confirm);

      modal.addEventListener('click', function(e) {
        if (e.target === modal) close();
      });

      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('modal-overlay--open')) close();
      });
    },
    open: open,
    close: close
  };
})();
