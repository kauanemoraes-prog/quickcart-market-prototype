/**
 * Equipment Restore Menu
 * Click on the slider+chevron grouped button opens a popover with two actions:
 * Reset (column default view) and Edit equipment settings.
 */

(function() {
  'use strict';

  window.EquipRestoreMenu = {
    init: function() {
      var btn = document.getElementById('equip-restore-btn');
      var menu = document.getElementById('equip-restore-menu');
      if (!btn || !menu) return;

      function open() {
        menu.removeAttribute('hidden');
        btn.setAttribute('aria-expanded', 'true');
      }

      function close() {
        menu.setAttribute('hidden', '');
        btn.setAttribute('aria-expanded', 'false');
      }

      function toggle() {
        if (menu.hasAttribute('hidden')) open(); else close();
      }

      btn.addEventListener('click', function(e) {
        e.stopPropagation();
        toggle();
      });

      document.addEventListener('click', function(e) {
        if (!e.target.closest('#equip-restore-menu') && !e.target.closest('#equip-restore-btn')) {
          close();
        }
      });

      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !menu.hasAttribute('hidden')) close();
      });

      menu.querySelectorAll('.equip-restore-menu__item').forEach(function(item) {
        item.addEventListener('click', function(e) {
          e.stopPropagation();
          if (item.dataset.action === 'reset') {
            // "Restore to column default view" — deactivate any active preset
            var engBtn = document.getElementById('equip-preset-btn');
            var readinessBtn = document.getElementById('equip-preset-readiness-btn');
            if (engBtn && engBtn.classList.contains('is-active')) engBtn.click();
            if (readinessBtn && readinessBtn.classList.contains('is-active')) readinessBtn.click();
          }
          close();
        });
      });
    }
  };
})();
