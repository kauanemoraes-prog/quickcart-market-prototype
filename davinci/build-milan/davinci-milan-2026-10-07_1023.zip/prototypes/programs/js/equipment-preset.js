/**
 * Equipment Presets
 * Toggle column-visibility presets on the Equipment - List table.
 * Multiple presets are mutually exclusive — activating one deactivates the other.
 */

(function() {
  'use strict';

  var TOTAL_COLS = 53;

  // Visible column positions (1-based) per preset.
  var PRESETS = {
    // Engineering Specs preset
    // Equipment name, Short name, ENG Intent, MP Intent, Equipment DRI,
    // OPL Adjustment, OPL, Cost rating, MP Cost Estimate, Weight kg,
    // Workspace Size, Line Name, Station Name, Equipment Usage Multiplier,
    // XUP, Man to Station Ratio, Handling CT, Machine CT, Cycle Time CT,
    // Cal + Audit, Retest Rate, Down time Planned, Down time Unplanned,
    // Yield Fallout, Testing.
    'engineering-specs': new Set([
      1, 2, 7, 8, 12, 18, 19, 22, 23, 29, 30, 36, 37, 38,
      42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52
    ]),

    // Equip. Readiness preset
    // Equipment name, Short name, Vendor DFM Statuses, ENG Intent, MP Intent,
    // Equipment DRI, PD DRI, Concept Review, RFP Link, Inline Part ID,
    // RFP Status, RFP Release Date, Reporting Method, Reporting Mapping.
    'readiness': new Set([
      1, 2, 3, 7, 8, 12, 13, 31, 32, 33, 34, 35, 40, 41
    ])
  };

  // Maps button id → preset key
  var BUTTON_TO_PRESET = {
    'equip-preset-btn': 'engineering-specs',
    'equip-preset-readiness-btn': 'readiness'
  };

  var activePreset = null;

  function setCellDisplay(cell, hidden) {
    cell.style.display = hidden ? 'none' : '';
  }

  function applyVisibility() {
    var headerRow = document.querySelector('.table--equipment thead tr');
    var body = document.getElementById('equipment-table-body');
    var visible = activePreset ? PRESETS[activePreset] : null;

    if (headerRow) {
      for (var i = 1; i <= TOTAL_COLS; i++) {
        var th = headerRow.children[i - 1];
        if (!th) continue;
        var hide = visible ? !visible.has(i) : false;
        setCellDisplay(th, hide);
      }
    }

    if (body) {
      body.querySelectorAll('tr.table__row').forEach(function(row) {
        if (row.classList.contains('table__row--actions-bar') || row.classList.contains('table__row--equip-expanded')) return;
        for (var i = 1; i <= TOTAL_COLS; i++) {
          var cell = row.children[i - 1];
          if (!cell) continue;
          var hide = visible ? !visible.has(i) : false;
          setCellDisplay(cell, hide);
        }
      });
    }

    updateButtonStates();
    updateHiddenCount();
  }

  function updateButtonStates() {
    Object.keys(BUTTON_TO_PRESET).forEach(function(btnId) {
      var btn = document.getElementById(btnId);
      if (!btn) return;
      var preset = BUTTON_TO_PRESET[btnId];
      var isActive = preset === activePreset;
      btn.classList.toggle('is-active', isActive);
      btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    });

    // Custom group wrapper is active when no preset is on
    var customGroup = document.getElementById('equip-restore-group');
    if (customGroup) {
      customGroup.classList.toggle('is-active', activePreset === null);
    }
  }

  function updateHiddenCount() {
    var badge = document.getElementById('equip-hidden-count');
    if (!badge) return;
    var headerRow = document.querySelector('.table--equipment thead tr');
    if (!headerRow) return;
    var hidden = 0;
    for (var i = 0; i < TOTAL_COLS; i++) {
      var th = headerRow.children[i];
      if (th && th.style.display === 'none') hidden++;
    }
    badge.textContent = hidden + '/' + TOTAL_COLS;
  }

  window.EquipmentPreset = {
    init: function() {
      updateHiddenCount();
      updateButtonStates();

      Object.keys(BUTTON_TO_PRESET).forEach(function(btnId) {
        var btn = document.getElementById(btnId);
        if (!btn) return;
        btn.addEventListener('click', function() {
          var preset = BUTTON_TO_PRESET[btnId];
          // Toggle off if clicking the active preset; otherwise switch to it
          activePreset = (activePreset === preset) ? null : preset;
          applyVisibility();
        });
      });

      // Custom button: always sets activePreset to null and shows all columns
      var customBtn = document.getElementById('equip-custom-btn');
      if (customBtn) {
        customBtn.addEventListener('click', function() {
          activePreset = null;
          applyVisibility();
        });
      }
    }
  };
})();
