/**
 * Program Detail Data Module
 * Contains lines and equipment data specific to detail page
 */

(function() {
  'use strict';
  
  // Build stages
  const buildStages = [
    { id: 'Pre P1', date: '01/15/2026' },
    { id: 'P1', date: '02/10/2026' },
    { id: 'P2', date: '03/20/2026' },
    { id: 'EVT', date: '05/05/2026' },
    { id: 'DVT', date: '07/14/2026' },
    { id: 'PVT', date: '09/22/2026' },
    { id: 'MP', date: '11/30/2026' }
  ];
  
  // Lines data
  const linesData = [
    { id: 1, name: 'SMT Line', nameTag: 'Lorem ipsum', description: 'Surface mount technology', lineType: 'Housing', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Lorem ipsum', targetUPH: 90, pcns: 0, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Solder Paste Print', processes: [{ name: 'Stencil alignment & paste application' }, { name: 'Paste inspection (SPI)' }] },
        { name: 'Pick & Place', processes: [{ name: 'Component placement' }] },
        { name: 'Reflow Oven', processes: [{ name: 'Thermal profile reflow' }, { name: 'Post-reflow AOI' }] },
        { name: 'Interposer Flex Tape/Foam Application', processes: [{ name: 'Tape and foam application on interposer' }] }
      ]
    },
    { id: 2, name: 'Final Assembly', nameTag: 'Lorem ipsum', description: 'Mechanical assembly & integration', lineType: 'Main', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Lorem ipsum', targetUPH: 75, pcns: 0, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Display Bonding', processes: [{ name: 'OCA lamination' }, { name: 'Bubble inspection' }] },
        { name: 'Battery Install', processes: [{ name: 'Battery placement & connector seating' }] },
        { name: 'Enclosure Seal', processes: [{ name: 'Gasket application & torque fastening' }] }
      ]
    },
    { id: 3, name: 'Testing', nameTag: 'Dolor emet', description: 'Functional & reliability testing', lineType: 'Main', level: 'Offline', condSop: '—', processCategory: 'FATP', lineGrouping: 'Dolor emet', targetUPH: 60, pcns: 0, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'PCBA Test', processes: [{ name: 'ICT boundary scan' }, { name: 'Functional power-on test' }] },
        { name: 'RF Calibration', processes: [{ name: 'Antenna tuning & RSSI validation' }] },
        { name: 'RF Calibration', processes: [{ name: 'Antenna tuning & RSSI validation' }] },
        { name: 'Run-In', processes: [{ name: 'Burn-in stress cycle' }, { name: 'Thermal cycling validation' }] }
      ]
    },
    { id: 4, name: 'Cosmetic & QC', nameTag: 'Cleaning Room', description: 'Visual inspection & quality control', lineType: 'Housing', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Cleaning Room', targetUPH: 100, pcns: 0, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Surface Inspection', processes: [{ name: 'Automated optical cosmetic scan' }] },
        { name: 'Laser Marking', processes: [{ name: 'Serial number engraving' }, { name: 'Regulatory marking' }] },
        { name: 'Final QC', processes: [{ name: 'Golden unit comparison' }] }
      ]
    },
    { id: 5, name: 'Packing', nameTag: 'Cleaning Room', description: 'Packaging & palletization', lineType: 'Main', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Cleaning Room', targetUPH: 85, pcns: 0, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Accessory Kit', processes: [{ name: 'Cable & adapter insertion' }] },
        { name: 'Box Seal', processes: [{ name: 'Product placement & foam insert' }, { name: 'Label print & apply' }] },
        { name: 'Palletize', processes: [{ name: 'Carton stacking & stretch wrap' }] }
      ]
    },
    { id: 6, name: 'Screen Bonding', nameTag: 'Lorem ipsum', description: 'Display lamination & module bonding', lineType: 'Housing', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Lorem ipsum', targetUPH: 55, pcns: 2, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'OCA Lamination', processes: [{ name: 'Film alignment & bond' }, { name: 'Bubble inspection' }] },
        { name: 'Autoclave', processes: [{ name: 'Pressure cure cycle' }] },
        { name: 'Screen QC', processes: [{ name: 'Optical uniformity check' }] }
      ]
    },
    { id: 7, name: 'Testing & Burn-in', nameTag: 'Dolor emet', description: 'Reliability stress & functional test', lineType: 'Main', level: 'Offline', condSop: '—', processCategory: 'FATP', lineGrouping: 'Dolor emet', targetUPH: 45, pcns: 1, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'ICT', processes: [{ name: 'Boundary scan' }, { name: 'Power rail check' }] },
        { name: 'Burn-in Chamber', processes: [{ name: 'Thermal cycling' }, { name: 'Voltage stress hold' }] },
        { name: 'Post-Burn Verify', processes: [{ name: 'Functional retest' }] },
        { name: 'Reliability QC', processes: [{ name: 'Golden unit comparison' }] }
      ]
    },
    { id: 8, name: 'Sub-Assembly', nameTag: 'Lorem ipsum', description: 'Housing sub-assembly prep', lineType: 'Housing', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Lorem ipsum', targetUPH: 80, pcns: 2, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Housing Prep', processes: [{ name: 'Deburring & cleaning' }] },
        { name: 'Frame Insert', processes: [{ name: 'Metal frame press-fit' }, { name: 'Post-press inspection' }] },
        { name: 'Sub-QC', processes: [{ name: 'Dimensional verification' }] }
      ]
    },
    { id: 9, name: 'Wire Harness', nameTag: 'Dolor emet', description: 'Cable & connector assembly', lineType: 'Main', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Dolor emet', targetUPH: 65, pcns: 1, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Cable Cut', processes: [{ name: 'Length calibration & cutting' }] },
        { name: 'Crimp', processes: [{ name: 'Terminal crimping' }, { name: 'Pull-test verification' }] },
        { name: 'Harness Assembly', processes: [{ name: 'Loom routing & lacing' }] },
        { name: 'Harness QC', processes: [{ name: 'Continuity check' }] }
      ]
    },
    { id: 10, name: 'Coating', nameTag: 'Cleaning Room', description: 'Surface treatment & priming', lineType: 'Housing', level: 'Offline', condSop: '—', processCategory: 'FATP', lineGrouping: 'Cleaning Room', targetUPH: 50, pcns: 0, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Surface Prep', processes: [{ name: 'Solvent wipe & tack cloth' }] },
        { name: 'Prime Coat', processes: [{ name: 'Spray application' }, { name: 'Flash-off cure' }] },
        { name: 'Top Coat', processes: [{ name: 'Base color spray' }, { name: 'Clear coat spray' }] }
      ]
    },
    { id: 11, name: 'Injection Molding', nameTag: 'Lorem ipsum', description: 'Polymer injection & de-flash', lineType: 'Housing', level: 'Online', condSop: '—', processCategory: 'SMT', lineGrouping: 'Lorem ipsum', targetUPH: 120, pcns: 3, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Mold Prep', processes: [{ name: 'Mold cleaning & release agent' }] },
        { name: 'Injection', processes: [{ name: 'Shot cycle' }, { name: 'Cool & eject' }] },
        { name: 'De-flash', processes: [{ name: 'Manual trim' }, { name: 'Sprue removal' }] }
      ]
    },
    { id: 12, name: 'Battery Assembly', nameTag: 'Dolor emet', description: 'Cell pack build & wrap', lineType: 'Main', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Dolor emet', targetUPH: 70, pcns: 1, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Cell Sort', processes: [{ name: 'IR & voltage grading' }] },
        { name: 'Spot Weld', processes: [{ name: 'Tab-to-cell welding' }, { name: 'Weld strength check' }] },
        { name: 'Pack Wrap', processes: [{ name: 'Kapton wrap & seal' }] }
      ]
    },
    { id: 13, name: 'Shipping Prep', nameTag: 'Cleaning Room', description: 'Boxing, palletize, freight', lineType: 'Main', level: 'Online', condSop: '—', processCategory: 'FATP', lineGrouping: 'Cleaning Room', targetUPH: 95, pcns: 0, stationCount: 25, processCount: 30, hc: 18, equipCount: 26, uniqueEquipCount: 12, uniqueCons: 10,
      stations: [
        { name: 'Master Carton', processes: [{ name: 'Master box seal' }] },
        { name: 'Freight Label', processes: [{ name: 'Waybill print & apply' }, { name: 'Scan & register' }] }
      ]
    }
  ];
  
  // Equipment data
  const equipmentData = [
    { name: 'Hammer', shortName: 'HMR-01', vendor: 'Approved', usage: '03', type: 'DFM', category: 'Manual Fixture', engIntent: 'MP Evaluation', mpIntent: 'MP Evaluation', lineSide: 'Left', qty: 5, date: '15 Mar 2026', dri: 'John Smith', pdDri: 'Jane Doe', cmDri: 'Bob Wilson' },
    { name: 'Screwdriver', shortName: 'SCR-02', vendor: 'Pending', usage: '05', type: 'TE', category: 'Semi Auto Fixture', engIntent: 'POR', mpIntent: 'MP Evaluation', lineSide: 'Right', qty: 10, date: '20 Mar 2026', dri: 'Alice Brown', pdDri: 'Charlie Davis', cmDri: 'Diana Evans' },
    { name: 'Pliers', shortName: 'PLR-03', vendor: 'Approved', usage: '01', type: 'AE', category: 'Bench Top Automated Fixture', engIntent: 'DOE', mpIntent: 'MP Evaluation', lineSide: 'Left', qty: 8, date: '18 Mar 2026', dri: 'Eve Foster', pdDri: 'Frank Green', cmDri: 'Grace Hill' },
    { name: 'Wrench', shortName: 'WRN-04', vendor: 'Approved', usage: '07', type: 'ME', category: 'Conveyor', engIntent: 'MP Evaluation', mpIntent: 'MP Evaluation', lineSide: 'Right', qty: 6, date: '22 Mar 2026', dri: 'Henry Irving', pdDri: 'Iris Jones', cmDri: 'Jack Kelly' },
    { name: 'Drill', shortName: 'DRL-05', vendor: 'In Review', usage: '02', type: 'Tool', category: 'Cooling Tunnel', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Left', qty: 3, date: '25 Mar 2026', dri: 'Kate Lewis', pdDri: 'Liam Martin', cmDri: 'Mia Nelson' },
    { name: 'Saw', shortName: 'SAW-06', vendor: 'Approved', usage: '00', type: 'DFM', category: 'Laser Etching', engIntent: 'Inactive', mpIntent: 'POR', lineSide: 'Right', qty: 2, date: '28 Mar 2026', dri: 'Noah Oliver', pdDri: 'Olivia Parker', cmDri: 'Paul Quinn' },
    { name: 'Sander', shortName: 'SND-07', vendor: 'Approved', usage: '04', type: 'TE', category: 'Laser Welding', engIntent: 'MP Evaluation', mpIntent: 'MP Evaluation', lineSide: 'Left', qty: 4, date: '30 Mar 2026', dri: 'Quinn Reed', pdDri: 'Rachel Scott', cmDri: 'Sam Taylor' },
    { name: 'Grinder', shortName: 'GRN-08', vendor: 'Pending', usage: '06', type: 'AE', category: 'Oven', engIntent: 'N/A', mpIntent: 'POR', lineSide: 'Right', qty: 2, date: '02 Apr 2026', dri: 'Tina Upton', pdDri: 'Uma Vance', cmDri: 'Victor Wade' },
    { name: 'Welder', shortName: 'WLD-09', vendor: 'In Review', usage: '08', type: 'ME', category: 'Manual Fixture', engIntent: 'Offline', mpIntent: 'DOE', lineSide: 'Left', qty: 1, date: '05 Apr 2026', dri: 'Wendy Xavier', pdDri: 'Xander Young', cmDri: 'Yara Zimmerman' },
    { name: 'Lathe', shortName: 'LTH-10', vendor: 'Approved', usage: '01', type: 'Tool', category: 'Semi Auto Fixture', engIntent: 'DOE', mpIntent: 'DOE', lineSide: 'Right', qty: 1, date: '08 Apr 2026', dri: 'Zoe Adams', pdDri: 'Aaron Baker', cmDri: 'Bella Carter' },
    { name: 'Pick & Place Machine', shortName: 'PNP-11', vendor: 'Approved', usage: '03', type: 'AE', category: 'Bench Top Automated Fixture', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Left', qty: 2, date: '12 Apr 2026', dri: 'Carlos Diaz', pdDri: 'Diana Ellis', cmDri: 'Ethan Ford' },
    { name: 'Reflow Oven', shortName: 'RFL-12', vendor: 'Approved', usage: '05', type: 'ME', category: 'Oven', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Right', qty: 1, date: '15 Apr 2026', dri: 'Fiona Grant', pdDri: 'George Hall', cmDri: 'Holly Ivers' },
    { name: 'AOI System', shortName: 'AOI-13', vendor: 'In Review', usage: '02', type: 'TE', category: 'Bench Top Automated Fixture', engIntent: 'MP Evaluation', mpIntent: 'POR', lineSide: 'Left', qty: 2, date: '18 Apr 2026', dri: 'Isaac Jackson', pdDri: 'Julia Klein', cmDri: 'Kevin Lopez' },
    { name: 'SPI Machine', shortName: 'SPI-14', vendor: 'Pending', usage: '04', type: 'TE', category: 'Semi Auto Fixture', engIntent: 'DOE', mpIntent: 'MP Evaluation', lineSide: 'Right', qty: 1, date: '20 Apr 2026', dri: 'Laura Moore', pdDri: 'Marco Nash', cmDri: 'Nina Owens' },
    { name: 'Wave Solder', shortName: 'WSL-15', vendor: 'Approved', usage: '06', type: 'ME', category: 'Conveyor', engIntent: 'Inactive', mpIntent: 'DOE', lineSide: 'Left', qty: 1, date: '22 Apr 2026', dri: 'Omar Prince', pdDri: 'Paula Quinn', cmDri: 'Quincy Reyes' },
    { name: 'Vacuum Chamber', shortName: 'VAC-16', vendor: 'Approved', usage: '00', type: 'AE', category: 'Manual Fixture', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Right', qty: 3, date: '25 Apr 2026', dri: 'Rita Silva', pdDri: 'Steve Torres', cmDri: 'Tara Ung' },
    { name: 'Torque Driver', shortName: 'TRQ-17', vendor: 'Approved', usage: '08', type: 'Tool', category: 'Manual Fixture', engIntent: 'MP Evaluation', mpIntent: 'MP Evaluation', lineSide: 'Left', qty: 12, date: '27 Apr 2026', dri: 'Ursula Vega', pdDri: 'Vince Walsh', cmDri: 'Wanda Xu' },
    { name: 'Laser Marker', shortName: 'LSR-18', vendor: 'In Review', usage: '03', type: 'AE', category: 'Laser Etching', engIntent: 'POR', mpIntent: 'MP Evaluation', lineSide: 'Right', qty: 2, date: '30 Apr 2026', dri: 'Xavier Yates', pdDri: 'Yolanda Zane', cmDri: 'Zach Abbott' },
    { name: 'ICT Fixture', shortName: 'ICT-19', vendor: 'Approved', usage: '07', type: 'TE', category: 'Bench Top Automated Fixture', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Left', qty: 4, date: '02 May 2026', dri: 'Andre Bishop', pdDri: 'Beatriz Chan', cmDri: 'Cyrus Diaz' },
    { name: 'RF Test Chamber', shortName: 'RFT-20', vendor: 'Pending', usage: '02', type: 'TE', category: 'Manual Fixture', engIntent: 'DOE', mpIntent: 'DOE', lineSide: 'Right', qty: 2, date: '05 May 2026', dri: 'Dora Elliot', pdDri: 'Erik Farrow', cmDri: 'Faye Gomez' },
    { name: 'Dispensing Robot', shortName: 'DSP-21', vendor: 'Approved', usage: '05', type: 'AE', category: 'Bench Top Automated Fixture', engIntent: 'MP Evaluation', mpIntent: 'POR', lineSide: 'Left', qty: 2, date: '08 May 2026', dri: 'Gustavo Hines', pdDri: 'Helena Ito', cmDri: 'Ivan Jansen' },
    { name: 'Ultrasonic Cleaner', shortName: 'USC-22', vendor: 'Approved', usage: '01', type: 'ME', category: 'Cooling Tunnel', engIntent: 'N/A', mpIntent: 'MP Evaluation', lineSide: 'Right', qty: 1, date: '10 May 2026', dri: 'Julia Kaur', pdDri: 'Kai Lam', cmDri: 'Leo Marsh' },
    { name: 'Thermal Camera', shortName: 'THC-23', vendor: 'In Review', usage: '04', type: 'TE', category: 'Manual Fixture', engIntent: 'DOE', mpIntent: 'DOE', lineSide: 'Left', qty: 3, date: '12 May 2026', dri: 'Mira Novak', pdDri: 'Nate Ortega', cmDri: 'Olga Park' },
    { name: 'CNC Router', shortName: 'CNC-24', vendor: 'Approved', usage: '00', type: 'ME', category: 'Semi Auto Fixture', engIntent: 'Offline', mpIntent: 'Inactive', lineSide: 'Right', qty: 1, date: '15 May 2026', dri: 'Peter Quon', pdDri: 'Queenie Ross', cmDri: 'Ryan Suzuki' },
    { name: 'Label Printer', shortName: 'LBL-25', vendor: 'Approved', usage: '06', type: 'Tool', category: 'FIFO', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Left', qty: 4, date: '18 May 2026', dri: 'Sofia Tanaka', pdDri: 'Theo Ueda', cmDri: 'Uma Vidal' },
    { name: 'Barcode Scanner', shortName: 'BCS-26', vendor: 'Approved', usage: '08', type: 'Tool', category: 'Manual Fixture', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Right', qty: 8, date: '20 May 2026', dri: 'Vera Wu', pdDri: 'Wesley Xiao', cmDri: 'Yasmin Zeng' },
    { name: 'Torque Wrench', shortName: 'TWR-27', vendor: 'Approved', usage: '03', type: 'Tool', category: 'Manual Fixture', engIntent: 'MP Evaluation', mpIntent: 'POR', lineSide: 'Left', qty: 15, date: '23 May 2026', dri: 'Aaron Cole', pdDri: 'Brianna Dutta', cmDri: 'Cesar Eng' },
    { name: 'Function Generator', shortName: 'FNG-28', vendor: 'In Review', usage: '02', type: 'TE', category: 'Bench Top Automated Fixture', engIntent: 'DOE', mpIntent: 'DOE', lineSide: 'Right', qty: 2, date: '25 May 2026', dri: 'Diego Furlan', pdDri: 'Ella Ghosh', cmDri: 'Felix Hsu' },
    { name: 'Oscilloscope', shortName: 'OSC-29', vendor: 'Approved', usage: '05', type: 'TE', category: 'Bench Top Automated Fixture', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Left', qty: 3, date: '28 May 2026', dri: 'Grace Ito', pdDri: 'Hugo Juarez', cmDri: 'Isla Kwon' },
    { name: 'Stencil Cleaner', shortName: 'STC-30', vendor: 'Pending', usage: '01', type: 'ME', category: 'Cooling Tunnel', engIntent: 'MP Evaluation', mpIntent: 'MP Evaluation', lineSide: 'Right', qty: 1, date: '30 May 2026', dri: 'Jamal Lin', pdDri: 'Karina Mota', cmDri: 'Leo Nakamura' },
    { name: 'Plasma Cleaner', shortName: 'PLC-31', vendor: 'Approved', usage: '07', type: 'ME', category: 'Cooling Tunnel', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Left', qty: 1, date: '02 Jun 2026', dri: 'Mateo Oduya', pdDri: 'Nadia Patel', cmDri: 'Oscar Qadir' },
    { name: 'PCB Router', shortName: 'PCB-32', vendor: 'Approved', usage: '04', type: 'ME', category: 'Conveyor', engIntent: 'DOE', mpIntent: 'MP Evaluation', lineSide: 'Right', qty: 1, date: '05 Jun 2026', dri: 'Priya Reddy', pdDri: 'Quinn Silva', cmDri: 'Ravi Thakur' },
    { name: 'Multimeter', shortName: 'MTR-33', vendor: 'Approved', usage: '06', type: 'TE', category: 'Manual Fixture', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Left', qty: 20, date: '08 Jun 2026', dri: 'Sarah Uy', pdDri: 'Tomas Vega', cmDri: 'Uma Wei' },
    { name: 'Conveyor Belt', shortName: 'CVB-34', vendor: 'In Review', usage: '00', type: 'ME', category: 'Conveyor', engIntent: 'POR', mpIntent: 'POR', lineSide: 'Right', qty: 5, date: '10 Jun 2026', dri: 'Victor Xie', pdDri: 'Willow Yao', cmDri: 'Xander Zaman' },
    { name: 'Robotic Arm', shortName: 'ROB-35', vendor: 'Pending', usage: '03', type: 'AE', category: 'Bench Top Automated Fixture', engIntent: 'DOE', mpIntent: 'DOE', lineSide: 'Left', qty: 2, date: '12 Jun 2026', dri: 'Yuki Aoki', pdDri: 'Zara Bello', cmDri: 'Adrian Cho' }
  ];
  
  // Consumables data
  const consumablesData = [
    { stationName: 'Station 01', applicationName: 'Assembly', consumableName: 'Adhesive Tape', vendor: 'Acme Corp', vendorPN: 'ADH-001', engIntent: 'Production', mpIntent: 'MP Evaluation', consumableType: 'Adhesive', category: 'Bonding', subcategory: 'Tape', itemDescription: 'Double-sided adhesive tape for component bonding', applePN: 'APL-ADH-001', cmPN: 'CM-ADH-001', package: 'Roll', packageUOM: 'EA', packageDescription: '50m roll', packageCost: '$25.00', purchasePack: '10', unitOfMeasure: 'Meter', costPerUOM: '$0.50', safetyDataSheet: 'SDS-001', technicalDataSheet: 'TDS-001', installedImage: 'IMG-001', usageTestPoints: '2.5', retestRate: '5%', lifecycle: '6 months', effectiveUsage: '2.38', testedRate: '95%', buildDuration: '30 days', buffer: '10%', engineeringDailyUsage: '12.5', engOrderQty: '375', inHandDate: '15 Apr 2026' },
    { stationName: 'Station 02', applicationName: 'Cleaning', consumableName: 'Cleaning Solution', vendor: 'CleanTech', vendorPN: 'CLN-002', engIntent: 'Production', mpIntent: 'MP Evaluation', consumableType: 'Chemical', category: 'Cleaning', subcategory: 'Solution', itemDescription: 'Industrial cleaning solution for electronics', applePN: 'APL-CLN-002', cmPN: 'CM-CLN-002', package: 'Bottle', packageUOM: 'EA', packageDescription: '1L bottle', packageCost: '$15.00', purchasePack: '12', unitOfMeasure: 'Liter', costPerUOM: '$15.00', safetyDataSheet: 'SDS-002', technicalDataSheet: 'TDS-002', installedImage: 'IMG-002', usageTestPoints: '1.0', retestRate: '2%', lifecycle: '12 months', effectiveUsage: '0.98', testedRate: '98%', buildDuration: '30 days', buffer: '15%', engineeringDailyUsage: '8.2', engOrderQty: '246', inHandDate: '22 Apr 2026' },
    { stationName: 'Station 03', applicationName: 'Protection', consumableName: 'Protective Film', vendor: 'FilmPro', vendorPN: 'PRT-003', engIntent: 'Production', mpIntent: 'MP Evaluation', consumableType: 'Film', category: 'Protection', subcategory: 'Surface', itemDescription: 'Protective film for display surfaces', applePN: 'APL-PRT-003', cmPN: 'CM-PRT-003', package: 'Roll', packageUOM: 'EA', packageDescription: '100m roll', packageCost: '$87.50', purchasePack: '5', unitOfMeasure: 'Meter', costPerUOM: '$0.88', safetyDataSheet: 'SDS-003', technicalDataSheet: 'TDS-003', installedImage: 'IMG-003', usageTestPoints: '1.2', retestRate: '3%', lifecycle: '18 months', effectiveUsage: '1.16', testedRate: '97%', buildDuration: '45 days', buffer: '12%', engineeringDailyUsage: '15.8', engOrderQty: '711', inHandDate: '10 May 2026' },
    { stationName: 'Station 01', applicationName: 'Thermal Management', consumableName: 'Thermal Paste', vendor: 'ThermalTech', vendorPN: 'THM-004', engIntent: 'Production', mpIntent: 'POR', consumableType: 'Paste', category: 'Thermal', subcategory: 'Interface', itemDescription: 'High-performance thermal interface paste', applePN: 'APL-THM-004', cmPN: 'CM-THM-004', package: 'Tube', packageUOM: 'EA', packageDescription: '10g tube', packageCost: '$12.00', purchasePack: '20', unitOfMeasure: 'Gram', costPerUOM: '$1.20', safetyDataSheet: 'SDS-004', technicalDataSheet: 'TDS-004', installedImage: 'IMG-004', usageTestPoints: '0.5', retestRate: '1%', lifecycle: '24 months', effectiveUsage: '0.495', testedRate: '99%', buildDuration: '30 days', buffer: '20%', engineeringDailyUsage: '3.2', engOrderQty: '96', inHandDate: '05 Apr 2026' },
    { stationName: 'Station 04', applicationName: 'Lubrication', consumableName: 'Lubricant Oil', vendor: 'OilCo', vendorPN: 'LUB-005', engIntent: 'Maintenance', mpIntent: 'MP Evaluation', consumableType: 'Oil', category: 'Lubricant', subcategory: 'Synthetic', itemDescription: 'Synthetic lubricant for precision mechanisms', applePN: 'APL-LUB-005', cmPN: 'CM-LUB-005', package: 'Bottle', packageUOM: 'EA', packageDescription: '500ml bottle', packageCost: '$25.00', purchasePack: '6', unitOfMeasure: 'Milliliter', costPerUOM: '$0.05', safetyDataSheet: 'SDS-005', technicalDataSheet: 'TDS-005', installedImage: 'IMG-005', usageTestPoints: '5.0', retestRate: '8%', lifecycle: '9 months', effectiveUsage: '4.6', testedRate: '92%', buildDuration: '60 days', buffer: '25%', engineeringDailyUsage: '18.4', engOrderQty: '1104', inHandDate: '28 Apr 2026' },
    { stationName: 'Station 05', applicationName: 'Soldering', consumableName: 'Solder Wire', vendor: 'SolderPro', vendorPN: 'SLD-006', engIntent: 'Production', mpIntent: 'POR', consumableType: 'Wire', category: 'Soldering', subcategory: 'Lead-Free', itemDescription: 'Lead-free solder wire SAC305', applePN: 'APL-SLD-006', cmPN: 'CM-SLD-006', package: 'Spool', packageUOM: 'EA', packageDescription: '500g spool', packageCost: '$92.50', purchasePack: '10', unitOfMeasure: 'Gram', costPerUOM: '$0.19', safetyDataSheet: 'SDS-006', technicalDataSheet: 'TDS-006', installedImage: 'IMG-006', usageTestPoints: '3.2', retestRate: '4%', lifecycle: '15 months', effectiveUsage: '3.07', testedRate: '96%', buildDuration: '30 days', buffer: '18%', engineeringDailyUsage: '22.1', engOrderQty: '663', inHandDate: '18 Apr 2026' },
    { stationName: 'Station 05', applicationName: 'Soldering', consumableName: 'Flux Paste', vendor: 'SolderPro', vendorPN: 'FLX-007', engIntent: 'Production', mpIntent: 'MP Evaluation', consumableType: 'Paste', category: 'Soldering', subcategory: 'No-Clean', itemDescription: 'No-clean flux paste for SMT', applePN: 'APL-FLX-007', cmPN: 'CM-FLX-007', package: 'Jar', packageUOM: 'EA', packageDescription: '100g jar', packageCost: '$18.00', purchasePack: '15', unitOfMeasure: 'Gram', costPerUOM: '$0.18', safetyDataSheet: 'SDS-007', technicalDataSheet: 'TDS-007', installedImage: 'IMG-007', usageTestPoints: '1.8', retestRate: '6%', lifecycle: '12 months', effectiveUsage: '1.69', testedRate: '94%', buildDuration: '30 days', buffer: '15%', engineeringDailyUsage: '9.7', engOrderQty: '291', inHandDate: '12 May 2026' },
    { stationName: 'Station 02', applicationName: 'Cleaning', consumableName: 'Isopropyl Alcohol', vendor: 'CleanTech', vendorPN: 'IPA-008', engIntent: 'Production', mpIntent: 'MP Evaluation', consumableType: 'Chemical', category: 'Cleaning', subcategory: 'Solvent', itemDescription: '99.9% pure isopropyl alcohol', applePN: 'APL-IPA-008', cmPN: 'CM-IPA-008', package: 'Bottle', packageUOM: 'EA', packageDescription: '1L bottle', packageCost: '$6.50', purchasePack: '24', unitOfMeasure: 'Liter', costPerUOM: '$6.50', safetyDataSheet: 'SDS-008', technicalDataSheet: 'TDS-008', installedImage: 'IMG-008', usageTestPoints: '0.8', retestRate: '1%', lifecycle: '24 months', effectiveUsage: '0.792', testedRate: '99%', buildDuration: '30 days', buffer: '10%', engineeringDailyUsage: '5.5', engOrderQty: '165', inHandDate: '08 Apr 2026' },
    { stationName: 'Station 06', applicationName: 'ESD Protection', consumableName: 'ESD Wrist Straps', vendor: 'SafetyFirst', vendorPN: 'ESD-009', engIntent: 'Safety', mpIntent: 'MP Evaluation', consumableType: 'Safety', category: 'ESD', subcategory: 'Grounding', itemDescription: 'Adjustable ESD wrist strap with ground cord', applePN: 'APL-ESD-009', cmPN: 'CM-ESD-009', package: 'Box', packageUOM: 'EA', packageDescription: '10 units per box', packageCost: '$32.50', purchasePack: '5', unitOfMeasure: 'Unit', costPerUOM: '$3.25', safetyDataSheet: 'SDS-009', technicalDataSheet: 'TDS-009', installedImage: 'IMG-009', usageTestPoints: '1.0', retestRate: '0%', lifecycle: '36 months', effectiveUsage: '1.0', testedRate: '100%', buildDuration: '90 days', buffer: '5%', engineeringDailyUsage: '2.8', engOrderQty: '252', inHandDate: '25 Apr 2026' },
    { stationName: 'Station 02', applicationName: 'Cleaning', consumableName: 'Lint-Free Wipes', vendor: 'CleanTech', vendorPN: 'WIP-010', engIntent: 'Production', mpIntent: 'MP Evaluation', consumableType: 'Wipe', category: 'Cleaning', subcategory: 'Disposable', itemDescription: 'Lint-free cleanroom wipes', applePN: 'APL-WIP-010', cmPN: 'CM-WIP-010', package: 'Box', packageUOM: 'EA', packageDescription: '100 wipes per box', packageCost: '$12.00', purchasePack: '20', unitOfMeasure: 'Wipe', costPerUOM: '$0.12', safetyDataSheet: 'SDS-010', technicalDataSheet: 'TDS-010', installedImage: 'IMG-010', usageTestPoints: '10.0', retestRate: '12%', lifecycle: '3 months', effectiveUsage: '8.8', testedRate: '88%', buildDuration: '30 days', buffer: '30%', engineeringDailyUsage: '45.2', engOrderQty: '1356', inHandDate: '02 May 2026' }
  ];
  
  // Programs whose Process Flow / Equipment / Consumables tabs should render empty
  const EMPTY_PROGRAMS = ['H95'];

  function getCurrentProgramCode() {
    try {
      var params = new URLSearchParams(window.location.search);
      return (params.get('code') || '').toUpperCase();
    } catch (e) {
      return '';
    }
  }

  function isEmptyProgram() {
    return EMPTY_PROGRAMS.indexOf(getCurrentProgramCode()) !== -1;
  }

  // Export to global scope
  window.DetailData = {
    getBuildStages: function() {
      return buildStages;
    },
    getLines: function() {
      return isEmptyProgram() ? [] : linesData;
    },
    getEquipment: function() {
      return isEmptyProgram() ? [] : equipmentData;
    },
    getConsumables: function() {
      return isEmptyProgram() ? [] : consumablesData;
    }
  };
})();
