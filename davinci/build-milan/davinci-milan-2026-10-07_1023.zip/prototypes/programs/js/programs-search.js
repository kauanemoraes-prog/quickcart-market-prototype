/**
 * Programs Search Module
 * Filters the programs table by text query (code, name, admin, sites[].alias)
 * and by the "Favorites only" toggle. Both filters are combined.
 */

(function() {
  'use strict';

  var state = { query: '', favoritesOnly: false };

  function matchesQuery(program, q) {
    if (!q) return true;
    if (program.code && program.code.toLowerCase().includes(q)) return true;
    if (program.name && program.name.toLowerCase().includes(q)) return true;
    if (program.admin && program.admin.toLowerCase().includes(q)) return true;
    if (Array.isArray(program.sites)) {
      for (var i = 0; i < program.sites.length; i++) {
        var alias = program.sites[i].alias;
        if (alias && alias.toLowerCase().includes(q)) return true;
      }
    }
    return false;
  }

  function buildPredicate() {
    if (!state.query && !state.favoritesOnly) return undefined;
    return function(program) {
      if (state.favoritesOnly && !program.favorite) return false;
      return matchesQuery(program, state.query);
    };
  }

  function rerender() {
    window.TableRenderer.render(buildPredicate());
    window.RowExpander.init();
    window.Favorites.init();
    window.ActionButtons.init();
  }

  window.ProgramsSearch = {
    init: function() {
      var input = document.getElementById('programs-search');
      if (input) {
        input.addEventListener('input', function(e) {
          state.query = (e.target.value || '').trim().toLowerCase();
          rerender();
        });
      }

      var favSwitch = document.getElementById('favorites-only');
      if (favSwitch) {
        favSwitch.addEventListener('change', function(e) {
          state.favoritesOnly = !!e.target.checked;
          rerender();
        });
      }
    }
  };
})();

