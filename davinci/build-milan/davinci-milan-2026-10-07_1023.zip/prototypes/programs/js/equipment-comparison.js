/**
 * Equipment Comparison Module
 * Renders the comparison table inside the Equipment Comparison sub-view
 * using the same equipment data source as the Equipment - List table.
 */

(function() {
  'use strict';

  function chevronIcon() {
    return '<svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M1.5 1L6.5 6L1.5 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</svg>';
  }

  function infoIcon() {
    return '<svg class="equip-compare__info-icon" width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<circle cx="7" cy="7" r="6" stroke="currentColor" stroke-width="1.25"/>' +
      '<path d="M7 6.25V10" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>' +
      '<circle cx="7" cy="4.25" r="0.75" fill="currentColor"/>' +
    '</svg>';
  }

  function notFoundCell() {
    return '<td class="table__cell"><span class="equip-compare__not-found">Not found ' + infoIcon() + '</span></td>';
  }

  function dashCell(extraClass) {
    return '<td class="table__cell' + (extraClass ? ' ' + extraClass : '') + '"><span class="equip-compare__dash">-</span></td>';
  }

  // Field labels mirror the Equipment - List table column headers.
  var equipFields = [
    'Equipment name',
    'Equipment short name',
    'Process Flow Usage',
    'Department',
    'Equipment category',
    'ENG Intent',
    'MP Intent',
    'Line Side',
    'Engineering quantity',
    'Required Equip. In-hand Date',
    'Equipment DRI',
    'PD DRI',
    'CM DRI',
    'Unique attributes',
    'Equip. description',
    'Equipment process',
    'OPL Adjustment',
    'OPL',
    'Priority rating',
    'Complexity rating',
    'Cost rating',
    'MP Cost Estimate',
    'Purchase type',
    'Revisions',
    'Notes',
    'Validation Required',
    'Validation Type',
    'Weight (kg)',
    'Workspace Size (X, Y, Z)',
    'Concept Review',
    'RFP Link',
    'RFP Status',
    'RFP Release Date',
    'Line Name',
    'Station Name',
    'Equipment Usage Multiplier',
    'Eq. Usage Connected to Reporting',
    'Reporting Method',
    'Reporting Mapping',
    'XUP',
    'Man to Station Ratio',
    'Handling CT',
    'Machine CT',
    'Cycle Time (CT)',
    'Cal + Audit',
    'Retest Rate',
    'Down time (Planned)',
    'Down time (Unplanned)',
    'Yield Fallout',
    'Testing',
    'Tooling'
  ];

  function buildSubRow(rowId, label) {
    return '<tr class="table__row equip-compare__sub-row" data-parent="' + rowId + '" style="display: none;">' +
      '<td class="table__cell equip-compare__sub-name">' + label + '</td>' +
      '<td class="table__cell"><span class="equip-compare__dash">-</span></td>' +
      '<td class="table__cell"><span class="equip-compare__dash">-</span></td>' +
      '<td class="table__cell"><span class="equip-compare__dash">-</span></td>' +
      '<td class="table__cell table__cell--current"><span class="equip-compare__dash">-</span></td>' +
      '<td class="table__cell"><span class="equip-compare__dash">-</span></td>' +
      '<td class="table__cell"><span class="equip-compare__dash">-</span></td>' +
      '<td class="table__cell"><span class="equip-compare__dash">-</span></td>' +
    '</tr>';
  }

  // Build-stage columns shown in the comparison header (P2 is the current build).
  var compareStages = [
    { label: 'Pre P1', active: true },
    { label: 'P1' },
    { label: 'P2', current: true },
    { label: 'EVT' },
    { label: 'DVT' },
    { label: 'PVT' }
  ];

  function renderStageHeaders() {
    var headerRow = document.getElementById('equip-compare-header-row');
    var tplEl = document.getElementById('equip-compare-stage-headers-template');
    if (!headerRow || !tplEl || typeof Handlebars === 'undefined') return;
    // Drop any previously-rendered stage <th>s; the first two static <th>s stay.
    while (headerRow.children.length > 2) headerRow.removeChild(headerRow.lastChild);
    var tpl = Handlebars.compile(tplEl.innerHTML);
    var holder = document.createElement('template');
    holder.innerHTML = tpl({ stages: compareStages }).trim();
    Array.prototype.forEach.call(holder.content.children, function(node) {
      headerRow.appendChild(node);
    });
  }

  window.EquipmentComparison = {
    render: function() {
      renderStageHeaders();

      var tbody = document.getElementById('equip-compare-body');
      if (!tbody) return;

      var data = (window.DetailData && window.DetailData.getEquipment) ? window.DetailData.getEquipment() : [];
      tbody.innerHTML = '';

      data.forEach(function(equip, idx) {
        var rowId = 'equip-compare-row-' + idx;
        var tr = document.createElement('tr');
        tr.className = 'table__row equip-compare__row';
        tr.dataset.rowId = rowId;
        tr.innerHTML =
          '<td class="table__cell equip-compare__name-cell">' +
            '<button class="equip-compare__chevron-btn" aria-label="Expand row">' + chevronIcon() + '</button>' +
            '<span class="equip-compare__name">' + equip.name + '</span>' +
          '</td>' +
          '<td class="table__cell">' + equip.shortName + '</td>' +
          notFoundCell() +
          notFoundCell() +
          dashCell('table__cell--current') +
          notFoundCell() +
          notFoundCell() +
          notFoundCell();
        tbody.appendChild(tr);

        // Sub-rows: one per Equipment - List column field
        var subRowsHtml = equipFields.map(function(label) {
          return buildSubRow(rowId, label);
        }).join('');
        var template = document.createElement('template');
        template.innerHTML = subRowsHtml;
        Array.prototype.forEach.call(template.content.children, function(node) {
          tbody.appendChild(node);
        });
      });

      // Chevron expand toggle
      tbody.querySelectorAll('.equip-compare__chevron-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
          var row = btn.closest('.equip-compare__row');
          var rowId = row.dataset.rowId;
          var subRows = tbody.querySelectorAll('.equip-compare__sub-row[data-parent="' + rowId + '"]');
          if (!subRows.length) return;
          var isOpen = subRows[0].style.display !== 'none';
          subRows.forEach(function(sub) {
            sub.style.display = isOpen ? 'none' : '';
          });
          btn.classList.toggle('equip-compare__chevron-btn--expanded', !isOpen);
          row.classList.toggle('equip-compare__row--expanded', !isOpen);
        });
      });

      // Search filter
      var searchInput = document.getElementById('equip-compare-search');
      if (searchInput && !searchInput.dataset.bound) {
        searchInput.dataset.bound = '1';
        searchInput.addEventListener('input', function() {
          var term = searchInput.value.trim().toLowerCase();
          tbody.querySelectorAll('.equip-compare__row').forEach(function(row) {
            var rowId = row.dataset.rowId;
            var subRows = tbody.querySelectorAll('.equip-compare__sub-row[data-parent="' + rowId + '"]');
            var nameCell = row.querySelector('.equip-compare__name');
            var name = (nameCell && nameCell.textContent || '').toLowerCase();
            var shortName = (row.children[1] && row.children[1].textContent || '').toLowerCase();
            var matches = !term || name.indexOf(term) !== -1 || shortName.indexOf(term) !== -1;
            row.style.display = matches ? '' : 'none';
            if (!matches) {
              subRows.forEach(function(sub) { sub.style.display = 'none'; });
            }
          });
        });
      }
      // Pin toggle in column headers
      var thead = tbody.parentElement && tbody.parentElement.querySelector('thead');
      if (thead && !thead.dataset.pinBound) {
        thead.dataset.pinBound = '1';
        thead.addEventListener('click', function(e) {
          var btn = e.target.closest('.equip-compare__pin-btn');
          if (!btn) return;
          var isActive = btn.classList.toggle('is-active');
          btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        });
      }
    }
  };
})();
