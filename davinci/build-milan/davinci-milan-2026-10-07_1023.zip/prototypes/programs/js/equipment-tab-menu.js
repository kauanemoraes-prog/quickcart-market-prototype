/**
 * Equipment Tab Menu
 * Switches between Equipment - List and Equipment Comparison sub-views
 * inside the Equipment - List tab.
 */

(function() {
  'use strict';

  window.EquipmentTabMenu = {
    init: function() {
      var menu = document.getElementById('equip-tab-menu');
      if (!menu) return;

      var listView = document.getElementById('equipment-list-view');
      var comparisonView = document.getElementById('equipment-comparison-view');

      menu.addEventListener('click', function(e) {
        var item = e.target.closest('.equip-tab-menu__item');
        if (!item) return;

        var view = item.dataset.view;
        var equipTab = document.querySelector('.tabs__tab[data-tab="equipment-list"]');
        var label = equipTab && equipTab.querySelector('.equip-tab-label');

        // Make sure the equipment-list tab is active
        if (equipTab && !equipTab.classList.contains('tabs__tab--active')) {
          equipTab.click();
        }

        // Toggle sub-views + update tab label
        if (view === 'comparison') {
          if (listView) listView.classList.remove('equip-view--active');
          if (comparisonView) comparisonView.classList.add('equip-view--active');
          if (label) label.textContent = 'Equipment - Comparison';
        } else {
          if (comparisonView) comparisonView.classList.remove('equip-view--active');
          if (listView) listView.classList.add('equip-view--active');
          if (label) label.textContent = 'Equipment – List';
        }

        // Update active state in menu
        menu.querySelectorAll('.equip-tab-menu__item').forEach(function(el) {
          el.classList.remove('equip-tab-menu__item--active');
        });
        item.classList.add('equip-tab-menu__item--active');

        // Hide popover after click (force CSS :hover to release)
        item.blur();
      });
    }
  };
})();
