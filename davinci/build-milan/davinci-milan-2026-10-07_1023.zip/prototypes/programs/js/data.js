/**
 * Shared Program Data
 * Used by both main programs page and program detail page
 */

(function() {
  'use strict';
  
  // Program data - 20 rows with H + 2 random numbers in descending order
  // Each program has nested sites data
  // Build sequence: Pre P1, P1, P2, EVT, DVT, PVT, MP
  const programsData = [
    {
      code: 'N50',
      name: 'MacBook Pro',
      admin: 'Lucas Silva',
      lastUpdate: '15 Jan 2026',
      favorite: false,
      sites: [
        { site: 'Site A', alias: 'MBP-2024', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '15 Jan 2026', favorite: false },
        { site: 'Site B', alias: 'MBP-PRO', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '14 Jan 2026', favorite: true },
        { site: 'Site C', alias: 'MBP-DEV', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '13 Jan 2026', favorite: false }
      ]
    },
    {
      code: 'H95',
      name: 'iPhone 15 Pro Max',
      admin: 'Ana Santos',
      lastUpdate: '28 Dec 2025',
      favorite: true,
      sites: [
        { site: 'Site A', alias: 'IP15-MAX', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '28 Dec 2025', favorite: true },
        { site: 'Site D', alias: 'IP15-PRO', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '27 Dec 2025', favorite: false }
      ]
    },
    {
      code: 'H92',
      name: 'iPad Air',
      admin: 'Pedro Oliveira',
      lastUpdate: '10 Feb 2026',
      favorite: false,
      sites: [
        { site: 'Site B', alias: 'IPAD-AIR', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '10 Feb 2026', favorite: false },
        { site: 'Site C', alias: 'IPAD-A5', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '09 Feb 2026', favorite: true },
        { site: 'Site E', alias: 'IPAD-DEV', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '08 Feb 2026', favorite: false }
      ]
    },
    {
      code: 'H88',
      name: 'AirPods Pro',
      admin: 'Maria Costa',
      lastUpdate: '22 Jan 2026',
      favorite: true,
      sites: [
        { site: 'Site A', alias: 'APODS-PRO', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '22 Jan 2026', favorite: true },
        { site: 'Site F', alias: 'APODS-2', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '21 Jan 2026', favorite: false }
      ]
    },
    {
      code: 'H84',
      name: 'Apple Watch Series 9',
      admin: 'João Ferreira',
      lastUpdate: '05 Feb 2026',
      favorite: false,
      sites: [
        { site: 'Site B', alias: 'AW-S9', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '05 Feb 2026', favorite: false },
        { site: 'Site C', alias: 'AW-SERIES9', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '04 Feb 2026', favorite: true }
      ]
    },
    {
      code: 'H79',
      name: 'Mac Mini',
      admin: 'Beatriz Almeida',
      lastUpdate: '18 Dec 2025',
      favorite: false,
      sites: [
        { site: 'Site D', alias: 'MINI-M2', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '18 Dec 2025', favorite: false },
        { site: 'Site E', alias: 'MINI-PRO', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '17 Dec 2025', favorite: false }
      ]
    },
    {
      code: 'H75',
      name: 'iPhone 14',
      admin: 'Carlos Rodrigues',
      lastUpdate: '03 Jan 2026',
      favorite: true,
      sites: [
        { site: 'Site A', alias: 'IP14-STD', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '03 Jan 2026', favorite: true },
        { site: 'Site B', alias: 'IP14-BASE', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '02 Jan 2026', favorite: false },
        { site: 'Site F', alias: 'IP14-DEV', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '01 Jan 2026', favorite: true }
      ]
    },
    {
      code: 'H71',
      name: 'MacBook Air',
      admin: 'Juliana Souza',
      lastUpdate: '25 Jan 2026',
      favorite: false,
      sites: [
        { site: 'Site C', alias: 'MBA-M2', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '25 Jan 2026', favorite: false },
        { site: 'Site D', alias: 'MBA-2024', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '24 Jan 2026', favorite: true }
      ]
    },
    {
      code: 'H67',
      name: 'iPad Pro',
      admin: 'Rafael Lima',
      lastUpdate: '12 Feb 2026',
      favorite: false,
      sites: [
        { site: 'Site A', alias: 'IPAD-PRO', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '12 Feb 2026', favorite: false },
        { site: 'Site E', alias: 'IPAD-P12', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '11 Feb 2026', favorite: false }
      ]
    },
    {
      code: 'H63',
      name: 'AirPods Max',
      admin: 'Fernanda Martins',
      lastUpdate: '08 Jan 2026',
      favorite: true,
      sites: [
        { site: 'Site B', alias: 'AMAX-2024', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '08 Jan 2026', favorite: true },
        { site: 'Site F', alias: 'AMAX-PRO', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '07 Jan 2026', favorite: false }
      ]
    },
    {
      code: 'H58',
      name: 'Mac Studio',
      admin: 'Gabriel Pereira',
      lastUpdate: '30 Dec 2025',
      favorite: false,
      sites: [
        { site: 'Site C', alias: 'STUDIO-M2', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '30 Dec 2025', favorite: false },
        { site: 'Site D', alias: 'STUDIO-MAX', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '29 Dec 2025', favorite: true }
      ]
    },
    {
      code: 'H54',
      name: 'iPhone 15',
      admin: 'Camila Ribeiro',
      lastUpdate: '20 Jan 2026',
      favorite: false,
      sites: [
        { site: 'Site A', alias: 'IP15-STD', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '20 Jan 2026', favorite: false },
        { site: 'Site E', alias: 'IP15-BASE', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '19 Jan 2026', favorite: false }
      ]
    },
    {
      code: 'H49',
      name: 'Apple TV 4K',
      admin: 'Bruno Carvalho',
      lastUpdate: '14 Feb 2026',
      favorite: true,
      sites: [
        { site: 'Site B', alias: 'ATV-4K', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '14 Feb 2026', favorite: true },
        { site: 'Site F', alias: 'ATV-2024', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '13 Feb 2026', favorite: false }
      ]
    },
    {
      code: 'H45',
      name: 'HomePod',
      admin: 'Patricia Gomes',
      lastUpdate: '02 Jan 2026',
      favorite: false,
      sites: [
        { site: 'Site C', alias: 'HPOD-2', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '02 Jan 2026', favorite: false },
        { site: 'Site D', alias: 'HPOD-GEN2', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '01 Jan 2026', favorite: false }
      ]
    },
    {
      code: 'H41',
      name: 'iMac 24"',
      admin: 'Ricardo Barbosa',
      lastUpdate: '27 Dec 2025',
      favorite: false,
      sites: [
        { site: 'Site A', alias: 'IMAC-24', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '27 Dec 2025', favorite: false },
        { site: 'Site E', alias: 'IMAC-M3', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '26 Dec 2025', favorite: true }
      ]
    },
    {
      code: 'H36',
      name: 'Magic Keyboard',
      admin: 'Larissa Dias',
      lastUpdate: '09 Feb 2026',
      favorite: true,
      sites: [
        { site: 'Site B', alias: 'MKB-2024', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '09 Feb 2026', favorite: true },
        { site: 'Site F', alias: 'MKB-PRO', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '08 Feb 2026', favorite: false }
      ]
    },
    {
      code: 'H32',
      name: 'Magic Mouse',
      admin: 'Thiago Araujo',
      lastUpdate: '16 Jan 2026',
      favorite: false,
      sites: [
        { site: 'Site C', alias: 'MMOUSE-2', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '16 Jan 2026', favorite: false },
        { site: 'Site D', alias: 'MMOUSE-BLK', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '15 Jan 2026', favorite: false }
      ]
    },
    {
      code: 'H28',
      name: 'iPhone 13',
      admin: 'Amanda Rocha',
      lastUpdate: '23 Dec 2025',
      favorite: false,
      sites: [
        { site: 'Site A', alias: 'IP13-STD', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '23 Dec 2025', favorite: false },
        { site: 'Site E', alias: 'IP13-BASE', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '22 Dec 2025', favorite: true }
      ]
    },
    {
      code: 'H23',
      name: 'iPad Mini',
      admin: 'Felipe Cardoso',
      lastUpdate: '06 Feb 2026',
      favorite: true,
      sites: [
        { site: 'Site B', alias: 'IPAD-MINI', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '06 Feb 2026', favorite: true },
        { site: 'Site F', alias: 'IPAD-M6', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '05 Feb 2026', favorite: false }
      ]
    },
    {
      code: 'H19',
      name: 'AirTag',
      admin: 'Isabela Mendes',
      lastUpdate: '11 Jan 2026',
      favorite: false,
      sites: [
        { site: 'Site C', alias: 'ATAG-2024', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '11 Jan 2026', favorite: false },
        { site: 'Site D', alias: 'ATAG-GEN1', builds: 'Pre P1, P1, P2, EVT, DVT, PVT, MP', lastUpdate: '10 Jan 2026', favorite: false }
      ]
    }
  ];
  
  // Export to global scope
  window.ProgramsData = {
    getAll: function() {
      return programsData;
    },
    findByCode: function(code) {
      return programsData.find(p => p.code === code);
    },
    add: function(program) {
      programsData.unshift(program);
    }
  };
})();
