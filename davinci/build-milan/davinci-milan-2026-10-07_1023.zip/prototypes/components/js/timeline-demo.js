(function() {
    'use strict';

    // Scenario 1 (3 dots): P1 is current + selected
    var scenario1 = [
        { label: 'P1', value: '04/01/2026', current: true,  selected: true },
        { label: 'P2', value: '04/15/2026', current: false, selected: false },
        { label: 'MP', value: '04/30/2026', current: false, selected: false }
    ];
    
    // Scenario 2 (3 dots): P1 is current, P2 is selected
    var scenario2 = [
        { label: 'P1', value: '04/01/2026', current: true,  selected: false },
        { label: 'P2', value: '04/15/2026', current: false, selected: true },
        { label: 'MP', value: '04/30/2026', current: false, selected: false }
    ];

    // Scenario 3 (6 dots): P2 is current + selected
    var scenario3 = [
        { label: 'P1', value: '04/01/2026', current: false, selected: false },
        { label: 'P2', value: '04/15/2026', current: true,  selected: true },
        { label: 'P3', value: '04/30/2026', current: false, selected: false },
        { label: 'EVT', value: 'TBD',       current: false, selected: false },
        { label: 'PVT', value: 'TBD',       current: false, selected: false },
        { label: 'MP',  value: '09/30/2026', current: false, selected: false }
    ];

    // Scenario 4 (6 dots): P2 is selected, P3 is current
    var scenario4 = [
        { label: 'P1', value: '04/01/2026', current: false, selected: false },
        { label: 'P2', value: '04/15/2026', current: false, selected: true },
        { label: 'P3', value: '04/30/2026', current: true,  selected: false },
        { label: 'EVT', value: 'TBD',       current: false, selected: false },
        { label: 'PVT', value: 'TBD',       current: false, selected: false },
        { label: 'MP',  value: '09/30/2026', current: false, selected: false }
    ];

    // Scenario 5 (6 dots): P3 is current, EVT is selected (future + selected)
    var scenario5 = [
        { label: 'P1', value: '04/01/2026', current: false, selected: false },
        { label: 'P2', value: '04/15/2026', current: false, selected: false },
        { label: 'P3', value: '04/30/2026', current: true,  selected: false },
        { label: 'EVT', value: 'TBD',       current: false, selected: true },
        { label: 'PVT', value: 'TBD',       current: false, selected: false },
        { label: 'MP',  value: '09/30/2026', current: false, selected: false }
    ];

    // Scenario 6 (6 dots): Same as 5 but P3 is draft (current + draft)
    var scenario6 = [
        { label: 'P1', value: '04/01/2026', current: false, selected: false },
        { label: 'P2', value: '04/15/2026', current: false, selected: false },
        { label: 'P3', value: '04/30/2026', current: true,  selected: false, draft: true },
        { label: 'EVT', value: 'TBD',       current: false, selected: true },
        { label: 'PVT', value: 'TBD',       current: false, selected: false },
        { label: 'MP',  value: '09/30/2026', current: false, selected: false }
    ];

    // Scenario 7 (4 dots): P1 is current + selected
    var scenario7 = [
        { label: 'P1', value: '04/01/2026', current: true,  selected: true },
        { label: 'P2', value: '04/15/2026', current: false, selected: false },
        { label: 'P3', value: '04/15/2026', current: false, selected: false },
        { label: 'MP', value: '04/30/2026', current: false, selected: false }
    ];
    

    window.TimelineDemo = {
        init: function() {
            var demos = [
                { id: 'timeline-demo-1', data: scenario1 },
                { id: 'timeline-demo-2', data: scenario2 },
                { id: 'timeline-demo-3', data: scenario3 },
                { id: 'timeline-demo-4', data: scenario4 },
                { id: 'timeline-demo-5', data: scenario5 },
                { id: 'timeline-demo-6', data: scenario6 },
                { id: 'timeline-demo-7', data: scenario7 }
            ];
            for (var i = 0; i < demos.length; i++) {
                ProjTimeline.create({
                    containerId: demos[i].id,
                    templateId: 'timeline-template',
                    milestones: demos[i].data
                }).init();
            }
        }
    };
})();
